using instituto93.Domain.DTOs;

namespace instituto93.Domain.Interfaces
{
    public interface IPreinscripcionRepository
    {
        Task<bool> ExisteDniAsync(string dni);
        Task<bool> GuardarAsync(PreinscripcionDto dto);
    }
}