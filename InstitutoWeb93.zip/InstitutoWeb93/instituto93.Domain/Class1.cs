﻿namespace instituto93.Domain;

public class Class1
{

}
