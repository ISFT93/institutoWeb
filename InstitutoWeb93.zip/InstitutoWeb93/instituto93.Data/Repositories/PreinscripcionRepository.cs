using instituto93.Domain.DTOs;
using instituto93.Domain.Interfaces;

namespace instituto93.Data.Repositories
{
    public class PreinscripcionRepository : IPreinscripcionRepository
    {
        public async Task<bool> ExisteDniAsync(string dni)
        {
            await Task.Delay(100);
            return false; 
        }

        public async Task<bool> GuardarAsync(PreinscripcionDto dto)
        {
            await Task.Delay(100);
            return true;
        }
    }
}