﻿namespace instituto93.Data;

public class Class1
{

}
