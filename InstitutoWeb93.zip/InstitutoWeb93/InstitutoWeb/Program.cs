using instituto93.Domain.Interfaces;
using instituto93.Data.Repositories;
using instituto93.Application.Interfaces;
using instituto93.Application.Services;
using InstitutoWeb.Components;

var builder = WebApplication.CreateBuilder(args);

// Registrar servicios en el contenedor de dependencias
builder.Services.AddScoped<IPreinscripcionRepository, PreinscripcionRepository>();
builder.Services.AddScoped<IPreinscripcionService, PreinscripcionService>();

builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri("https://localhost:7275/") });
// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();