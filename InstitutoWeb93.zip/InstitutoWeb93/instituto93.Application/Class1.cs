﻿namespace instituto93.Application;

public class Class1
{

}
