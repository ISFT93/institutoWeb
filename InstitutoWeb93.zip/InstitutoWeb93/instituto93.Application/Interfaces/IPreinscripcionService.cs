using instituto93.Domain.DTOs;

namespace instituto93.Application.Interfaces
{
    public interface IPreinscripcionService
    {
        Task<(bool Exito, string Mensaje)> RegistrarPreinscripcionAsync(PreinscripcionDto dto);
    }
}