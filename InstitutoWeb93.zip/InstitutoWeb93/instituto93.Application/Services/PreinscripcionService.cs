using instituto93.Application.Interfaces;
using instituto93.Domain.DTOs;
using instituto93.Domain.Interfaces;

namespace instituto93.Application.Services
{
    public class PreinscripcionService : IPreinscripcionService
    {
        private readonly IPreinscripcionRepository _repository;

        public PreinscripcionService(IPreinscripcionRepository repository)
        {
            _repository = repository;
        }

        public async Task<(bool Exito, string Mensaje)> RegistrarPreinscripcionAsync(PreinscripcionDto dto)
        {
            if (await _repository.ExisteDniAsync(dto.Dni))
            {
                return (false, "El DNI ingresado ya registra una preinscripción.");
            }

            bool guardado = await _repository.GuardarAsync(dto);
            return guardado 
                ? (true, "¡Preinscripción registrada con éxito!") 
                : (false, "Error al intentar guardar la preinscripción.");
        }
    }
}